from flask import Flask, request
from prometheus_client import Counter, Gauge, generate_latest, CONTENT_TYPE_LATEST

app = Flask(__name__)

# Metrics
api_call_counter = Counter('api_calls_total', 'Total number of API calls')
token_usage_gauge = Gauge('token_usage', 'Token usage')

@app.route('/metrics', methods=['GET'])
def metrics():
    return generate_latest(), 200, {'Content-Type': CONTENT_TYPE_LATEST}

@app.route('/update_metrics', methods=['POST'])
def update_metrics():
    data = request.json
    if 'api_calls' in data:
        api_call_counter.inc(data['api_calls'])  # Increment the counter by the number of API calls
    if 'token_usage' in data:
        token_usage_gauge.set(data['token_usage'])  # Set the current token usage
    return '', 204

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
